#include "iss.h"

// 전역 변수 정의
uint32_t R[16];
APSR_t APSR;
uint8_t *mem;
int branch;
uint32_t EXE_PC;

